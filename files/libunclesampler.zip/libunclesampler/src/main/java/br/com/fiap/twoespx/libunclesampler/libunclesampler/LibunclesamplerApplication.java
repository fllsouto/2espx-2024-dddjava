package br.com.fiap.twoespx.libunclesampler.libunclesampler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibunclesamplerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibunclesamplerApplication.class, args);
	}

}
