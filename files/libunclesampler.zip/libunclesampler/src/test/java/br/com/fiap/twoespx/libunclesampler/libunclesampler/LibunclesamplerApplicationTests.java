package br.com.fiap.twoespx.libunclesampler.libunclesampler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibunclesamplerApplicationTests {

	@Test
	void contextLoads() {
	}

}
